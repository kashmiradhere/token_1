package com.example.student;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class studentActivity extends AppCompatActivity {
    private TextView text,textView6;
    private EditText name, section;
    DatabaseReference ref;
    String oldVersionC = "T0";
    String currTokenC;
    String T,n;
    Button get, viewtoken;
    private ChildEventListener mChildEventListener = new ChildEventListener() {
        @Override
        public void onChildAdded(DataSnapshot dataSnapshot, String s) {

            Log.d("TrailCFB", "Child added event");
            oldVersionC = "T" + (Integer.parseInt(oldVersionC.substring(1)) + 1);
            currTokenC = oldVersionC;
        }

        @Override
        public void onChildChanged(DataSnapshot dataSnapshot, String s) {

        }

        @Override
        public void onChildRemoved(DataSnapshot dataSnapshot) {

        }

        @Override
        public void onChildMoved(DataSnapshot dataSnapshot, String s) {

        }

        @Override
        public void onCancelled(DatabaseError databaseError) {

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        text = findViewById(R.id.textView);
        name = findViewById(R.id.name);
        section = findViewById(R.id.section);
        get = findViewById(R.id.get);
        viewtoken = findViewById(R.id.viewtoken);
        textView6=findViewById(R.id.textView6);

        ref = FirebaseDatabase.getInstance().getReference().child("student");
        ref.addChildEventListener(mChildEventListener);

        get.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                ad stud=new ad();
                String adminnum = "T" +n;
                System.out.println(adminnum);
                System.out.println(oldVersionC);
                boolean b=adminnum.equals(oldVersionC);
                System.out.println(b);
                if (b) {

                    Toast.makeText(studentActivity.this, "out of stock", Toast.LENGTH_SHORT).show();
                } else {
                    String sec = section.getText().toString();
                    String nam = name.getText().toString();


                    stud.setSection(sec);
                    stud.setName(nam);
                    ref.push().setValue(stud).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Log.d("TrailCFB", "Task Successful");
                                invokeAlert();

                                viewtoken.setVisibility(View.VISIBLE);
                                textView6.setVisibility(View.VISIBLE);

                            }
                        }
                    });

                }
            }
        });


        viewtoken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                invokeAlertremove();
            }
        });


        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ad inf = new ad();
                inf = dataSnapshot.getValue(ad.class);
                T=inf.getTime();
                n=inf.getNumber();
                String k = "No of students\t\t" + inf.getNumber() + "\nTime slot\t\t\t" + inf.getTime();
                text.setText(k);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    public void invokeAlert() {

        AlertDialog.Builder a = new AlertDialog.Builder(this);
        a.setTitle("Reminder");
        a.setMessage("Your Token number is " + oldVersionC);
        a.setCancelable(true);
        a.show();

    }


    public void invokeAlertremove() {




        final AlertDialog.Builder a2 = new AlertDialog.Builder(this);
        a2.setTitle("Token Details");
        a2.setMessage("My Token number is: " + oldVersionC + "\n" + "Time Slot: " + T);

        a2.setPositiveButton("Ok", null);
        a2.setNegativeButton("Remove Token", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("TrailCFB", "Remove Token");


            }
        })
                .setCancelable(false)
                .show();

    }
}

