package com.example.student;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class T_admin_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t_admin_list);
    }
}